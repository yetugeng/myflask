#-*- coding:utf-8 -*-
from app import app
app.run(debug = True, port=1234)