#-*- coding:utf-8 -*-

from app import app
@app.route('/')
@app.route('/index')
def index():
    user = {
            'nickname':'Miguel',
            'myname':'yetugeng'
            }
    return '''
<html>
    <head>
        <title>Home标签</title>
    </head>
    <body>
        <h1>Hello, ''' + user['nickname'] + '''</h1>
        <h2>Hello, ''' + user['myname'] + '''</h2>
    </body>
</html>
    '''
#     return  user['myname']